package com.ui.ApkSteady.ui;

import android.os.Bundle;
import android.view.View;
import android.view.ViewStub;
import android.widget.ImageView;

import com.ui.ApkSteady.R;

public class DetailActivity extends BaseCommonActivity {

    private ImageView mBackIv;
    private ViewStub stubNoDiscuss;
    private int CONTAINSTATE = 0;//0无评论，1有评论，2比赛数据

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.my_fragment);
        setContentView(R.layout.match_detail_activity);

        mBackIv = findViewById(R.id.imageView_detail_back);
        mBackIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        switch (CONTAINSTATE) {
            case 0:
                stubNoDiscuss = (ViewStub) findViewById(R.id.viewstub_detail_contain_nodiscuss);
                stubNoDiscuss.inflate();
                break;
            case 1:
                break;
            case 2:
                break;
            default:
                stubNoDiscuss = (ViewStub) findViewById(R.id.viewstub_detail_contain_nodiscuss);
                stubNoDiscuss.inflate();
        }

    }
}