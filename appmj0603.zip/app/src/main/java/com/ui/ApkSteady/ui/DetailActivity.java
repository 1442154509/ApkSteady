package com.ui.ApkSteady.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.ui.ApkSteady.R;

public class DetailActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
    }
}